اقرا هذا قبل أي شيء:

1. الصور: مجلد "images" هنا فارغ — لازم تنسخ فيه الصور
   اللي حملتها من قبل (Download/images على هاتفك) — نفس الأسماء
   بالضبط، السكريبت والملف متوافقين 100%.

2. بعد ما تحط الصور، ارفع المجلد كامل (index.html, admin.html,
   products.json, images/) لريبو GitHub تاعك: kador24/Aziz-phone

3. افتح admin.html من المتصفح (بعد رفعه)، حط توكن GitHub
   الجديد لي أنشأتو، وابدا تعدّل.

4. الموقع العمومي يبان على:
   https://kador24.github.io/Aziz-phone/index.html
